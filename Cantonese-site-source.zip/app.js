const STORAGE_KEY = "cantonese-review-state-v1";
const DAY_ORDER = [
  { id: "day1", label: "Day 1" },
  { id: "day2", label: "Day 2" }
];
const MODULE_ORDER = ["全部內容", "聲母", "韻母", "聲調", "常用字表", "句子"];
const TYPE_LABELS = {
  jyutping: "粵拼識別",
  meaning: "普通話釋義",
  reverse: "粵語反查",
  sentenceJyutping: "句子發音"
};

let activeDay = "day1";
let activeModule = "全部內容";
let wrongOnly = false;
let currentQuestion = null;
let state = loadState();

const items = window.STUDY_ITEMS;
const byId = new Map(items.map((item) => [item.id, item]));
const sentenceAudio = new Audio();

const els = {
  dayNav: document.querySelector("#dayNav"),
  moduleNav: document.querySelector("#moduleNav"),
  activeModuleLabel: document.querySelector("#activeModuleLabel"),
  progressPercent: document.querySelector("#progressPercent"),
  doneCount: document.querySelector("#doneCount"),
  totalCount: document.querySelector("#totalCount"),
  resetTodayBtn: document.querySelector("#resetTodayBtn"),
  wrongOnlyBtn: document.querySelector("#wrongOnlyBtn"),
  shuffleBtn: document.querySelector("#shuffleBtn"),
  quizCategory: document.querySelector("#quizCategory"),
  quizType: document.querySelector("#quizType"),
  questionPrompt: document.querySelector("#questionPrompt"),
  questionStem: document.querySelector("#questionStem"),
  options: document.querySelector("#options"),
  feedback: document.querySelector("#feedback"),
  againBtn: document.querySelector("#againBtn"),
  knownBtn: document.querySelector("#knownBtn"),
  factTraditionalLabel: document.querySelector("#factTraditionalLabel"),
  factJyutpingLabel: document.querySelector("#factJyutpingLabel"),
  factMandarinLabel: document.querySelector("#factMandarinLabel"),
  factTraditional: document.querySelector("#factTraditional"),
  factJyutping: document.querySelector("#factJyutping"),
  factMandarin: document.querySelector("#factMandarin"),
  examplesBlock: document.querySelector("#examplesBlock"),
  wrongList: document.querySelector("#wrongList")
};

function loadState() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    return {
      done: parsed.done || {},
      wrong: parsed.wrong || {},
      familiarity: parsed.familiarity || {}
    };
  } catch {
    return { done: {}, wrong: {}, familiarity: {} };
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function itemDay(item) {
  return item.day || "day1";
}

function filteredItems() {
  let pool = items.filter((item) => itemDay(item) === activeDay);
  if (activeModule !== "全部內容") {
    pool = pool.filter((item) => item.module === activeModule);
  }
  if (wrongOnly) {
    pool = pool.filter((item) => state.wrong[item.id]);
  }
  return pool;
}

function buildDays() {
  els.dayNav.innerHTML = "";
  DAY_ORDER.forEach((day) => {
    const count = items.filter((item) => itemDay(item) === day.id).length;
    const button = document.createElement("button");
    button.className = `day-button${day.id === activeDay ? " active" : ""}`;
    button.type = "button";
    button.textContent = `${day.label} · ${count}`;
    button.addEventListener("click", () => {
      activeDay = day.id;
      activeModule = "全部內容";
      wrongOnly = false;
      els.wrongOnlyBtn.classList.remove("active");
      render();
    });
    els.dayNav.append(button);
  });
}

function buildModules() {
  els.moduleNav.innerHTML = "";
  MODULE_ORDER.forEach((module) => {
    const dayItems = items.filter((item) => itemDay(item) === activeDay);
    const count = module === "全部內容" ? dayItems.length : dayItems.filter((item) => item.module === module).length;
    const button = document.createElement("button");
    button.className = `module-button${module === activeModule ? " active" : ""}`;
    button.type = "button";
    button.innerHTML = `<span>${module}</span><span class="module-count">${count}</span>`;
    button.addEventListener("click", () => {
      activeModule = module;
      wrongOnly = false;
      els.wrongOnlyBtn.classList.remove("active");
      render();
    });
    els.moduleNav.append(button);
  });
}

function makeQuestion() {
  const pool = filteredItems();
  if (!pool.length) {
    currentQuestion = null;
    return;
  }

  const sorted = [...pool].sort((a, b) => (state.familiarity[a.id] || 0) - (state.familiarity[b.id] || 0));
  const candidates = sorted.slice(0, Math.min(12, sorted.length));
  const item = sample(candidates);
  const type = sample(item.questionTypes);
  currentQuestion = { item, type };
}

function getQuestionText(item, type) {
  if (type === "sentenceJyutping") {
    return { prompt: "看普通話，說出粵語，再聽標準發音確認", stem: item.mandarin || item.simplified || item.traditional, answer: item.jyutping, field: "jyutping" };
  }
  if (type === "jyutping") {
    return { prompt: "選出正確粵拼", stem: item.traditional, answer: item.jyutping, field: "jyutping" };
  }
  if (type === "meaning") {
    return { prompt: "選出普通話意思", stem: item.traditional, answer: item.mandarin, field: "mandarin" };
  }
  return { prompt: "根據普通話意思選出粵語", stem: item.mandarin, answer: item.traditional, field: "traditional" };
}

function buildOptions(item, type) {
  const { answer, field } = getQuestionText(item, type);
  const source = items
    .filter((candidate) => candidate.id !== item.id)
    .map((candidate) => ({
      candidate,
      score: optionScore(item, candidate, type, field)
    }))
    .sort((a, b) => b.score - a.score || Math.random() - 0.5)
    .map(({ candidate }) => optionForCandidate(candidate, field, type))
    .filter((option, index, values) => option.value && option.value !== answer && values.findIndex((value) => value.value === option.value) === index)
    .slice(0, 3);
  return shuffle([optionForCandidate(item, field, type), ...source]);
}

function optionForCandidate(candidate, field, type) {
  const value = candidate[field];
  return { value, label: value };
}

function optionScore(item, candidate, type, field) {
  let score = 0;
  if (itemDay(candidate) === itemDay(item)) score += 60;
  if (candidate.module === item.module) score += 40;
  if (candidate.category === item.category) score += 35;

  if (type === "jyutping" || type === "sentenceJyutping") {
    const a = parseJyutping(item.jyutping);
    const b = parseJyutping(candidate.jyutping);
    if (a.syllables === b.syllables) score += 18;
    if (a.tones === b.tones) score += 12;
    if (rimeKey(a.base) === rimeKey(b.base)) score += 24;
    if (a.base[0] && a.base[0] === b.base[0]) score += 8;
    if (a.base.at(-1) && a.base.at(-1) === b.base.at(-1)) score += 8;
    score += Math.max(0, 16 - editDistance(a.base, b.base) * 4);
  } else {
    const a = String(item[field]);
    const b = String(candidate[field]);
    if (a.length === b.length) score += 6;
    score += Math.max(0, 10 - Math.abs(a.length - b.length) * 2);
  }

  return score;
}

function rimeKey(base) {
  return base
    .split(/\s+/)
    .map((syllable) => syllable.replace(/^(gw|kw|ng|[bpmfdtnlzcsjgkhyw])/, ""))
    .join(" ");
}

function parseJyutping(value) {
  const parts = String(value).trim().split(/\s+/);
  return {
    base: parts.map((part) => part.replace(/[1-6]/g, "")).join(" "),
    tones: parts.map((part) => part.match(/[1-6]/)?.[0] || "").join(""),
    syllables: parts.length
  };
}

function editDistance(a, b) {
  const rows = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i += 1) rows[i][0] = i;
  for (let j = 0; j <= b.length; j += 1) rows[0][j] = j;
  for (let i = 1; i <= a.length; i += 1) {
    for (let j = 1; j <= b.length; j += 1) {
      rows[i][j] = Math.min(
        rows[i - 1][j] + 1,
        rows[i][j - 1] + 1,
        rows[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
  }
  return rows[a.length][b.length];
}

function renderQuestion() {
  if (!currentQuestion) {
    els.quizCategory.textContent = wrongOnly ? "錯題本" : activeModule;
    els.quizType.textContent = "-";
    els.questionPrompt.textContent = wrongOnly ? "目前沒有錯題。" : "這個篩選沒有可練習內容。";
    els.questionStem.innerHTML = "<small>換個模組試試。</small>";
    els.options.innerHTML = "";
    els.feedback.hidden = true;
    return;
  }

  const { item, type } = currentQuestion;
  const question = getQuestionText(item, type);
  els.questionStem.classList.toggle("sentence-stem", type === "sentenceJyutping");
  els.quizCategory.textContent = item.category;
  els.quizType.textContent = TYPE_LABELS[type];
  els.questionPrompt.textContent = question.prompt;
  renderQuestionStem(item, type, question);
  els.feedback.hidden = true;
  els.feedback.textContent = "";
  els.options.innerHTML = "";

  buildOptions(item, type).forEach((option) => {
    const button = document.createElement("button");
    button.className = "option-button";
    button.type = "button";
    button.textContent = option.label;
    button.dataset.value = option.value;
    button.addEventListener("click", () => answer(option.value, question.answer));
    els.options.append(button);
  });

  renderFactPanel(item, type);
  els.examplesBlock.innerHTML = item.examples.length
    ? `<strong>例：</strong>${item.examples.map(escapeHtml).join(" · ")}`
    : "";
}

function renderQuestionStem(item, type, question) {
  els.questionStem.textContent = "";
  if (type !== "sentenceJyutping") {
    els.questionStem.innerHTML = `${escapeHtml(question.stem)}<small>${escapeHtml(item.module)} · ${escapeHtml(item.category)}</small>`;
    return;
  }

  const block = document.createElement("div");
  block.className = "sentence-block";

  const mandarin = document.createElement("p");
  mandarin.className = "sentence-mandarin";
  mandarin.textContent = question.stem;

  const practiceRow = document.createElement("div");
  practiceRow.className = "sentence-practice-row";
  practiceRow.append(createAudioButton(item));

  const meta = document.createElement("small");
  meta.textContent = `${item.module} · ${item.category}`;

  block.append(mandarin, practiceRow, meta);
  els.questionStem.append(block);
}

function getDisplayText(item) {
  return item.cantonese || item.traditional;
}

function renderFactPanel(item, type) {
  if (type === "sentenceJyutping") {
    renderSentenceFactPanel(item);
    return;
  }

  els.factTraditionalLabel.textContent = "粵語";
  els.factJyutpingLabel.textContent = "粵拼";
  els.factMandarinLabel.textContent = "普通話";
  renderFactTraditional(item);
  els.factJyutping.textContent = item.jyutping;
  els.factMandarin.textContent = item.mandarin;
}

function renderSentenceFactPanel(item) {
  els.factTraditionalLabel.textContent = "普通話";
  els.factJyutpingLabel.textContent = "練習";
  els.factMandarinLabel.textContent = "提示";
  els.factTraditional.textContent = "";
  const text = document.createElement("span");
  text.textContent = item.mandarin;
  els.factTraditional.append(text, createAudioButton(item));
  els.factJyutping.textContent = "先自己說，再選答案";
  els.factMandarin.textContent = item.mandarin;
}

function renderFactTraditional(item) {
  els.factTraditional.textContent = "";
  const text = document.createElement("span");
  text.textContent = getDisplayText(item);
  els.factTraditional.append(text);
  if (item.questionTypes.includes("sentenceJyutping")) {
    els.factTraditional.append(createAudioButton(item));
  }
}

function createAudioButton(item) {
  const button = document.createElement("button");
  button.className = "audio-button";
  button.type = "button";
  button.textContent = "▶";
  button.title = "播放粵語發音";
  button.setAttribute("aria-label", `播放粵語發音：${getDisplayText(item)}`);
  button.addEventListener("click", (event) => {
    event.stopPropagation();
    playSentenceAudio(item, button);
  });
  return button;
}

function playSentenceAudio(item, button) {
  sentenceAudio.pause();
  sentenceAudio.currentTime = 0;
  sentenceAudio.src = `audio/sentences/${item.id}.m4a`;
  button.classList.add("playing");
  button.textContent = "■";
  sentenceAudio.onended = () => {
    button.classList.remove("playing");
    button.textContent = "▶";
  };
  sentenceAudio.play().catch(() => {
    button.classList.remove("playing");
    button.textContent = "▶";
    els.feedback.textContent = "音頻暫時無法播放，請確認 audio/sentences 裡的檔案存在。";
    els.feedback.hidden = false;
  });
}

function answer(selected, correct) {
  if (!currentQuestion) return;
  const isCorrect = selected === correct;
  const { item } = currentQuestion;

  [...els.options.children].forEach((button) => {
    button.disabled = true;
    if (button.dataset.value === correct) button.classList.add("correct");
    if (button.dataset.value === selected && !isCorrect) button.classList.add("incorrect");
  });

  if (isCorrect) {
    state.done[item.id] = true;
    delete state.wrong[item.id];
    state.familiarity[item.id] = Math.min(5, (state.familiarity[item.id] || 0) + 1);
    els.feedback.textContent = `答對了：${getDisplayText(item)} · ${item.jyutping} · ${item.mandarin}`;
  } else {
    state.wrong[item.id] = true;
    state.familiarity[item.id] = Math.max(-3, (state.familiarity[item.id] || 0) - 1);
    els.feedback.textContent = `正確答案是：${correct}`;
  }
  els.feedback.hidden = false;
  saveState();
  renderProgress();
  renderWrongList();
}

function renderProgress() {
  const pool = filteredItems();
  const total = pool.length;
  const done = pool.filter((item) => state.done[item.id]).length;
  const percent = total ? Math.round((done / total) * 100) : 0;
  els.progressPercent.textContent = `${percent}%`;
  els.doneCount.textContent = String(done);
  els.totalCount.textContent = String(total);
  document.documentElement.style.setProperty("--progress", `${percent * 3.6}deg`);
}

function renderWrongList() {
  const wrongItems = Object.keys(state.wrong)
    .map((id) => byId.get(id))
    .filter(Boolean)
    .slice(0, 8);
  els.wrongList.innerHTML = "";
  if (!wrongItems.length) {
    els.wrongList.textContent = "暫時沒有錯題。";
    return;
  }
  wrongItems.forEach((item) => {
    const row = document.createElement("div");
    row.className = "wrong-item";
    row.innerHTML = `<strong>${escapeHtml(item.traditional)}</strong><span>${escapeHtml(item.jyutping)}</span>`;
    els.wrongList.append(row);
  });
}

function render() {
  buildDays();
  buildModules();
  const dayLabel = DAY_ORDER.find((day) => day.id === activeDay)?.label || activeDay;
  els.activeModuleLabel.textContent = wrongOnly ? `${dayLabel} · 錯題本` : `${dayLabel} · ${activeModule}`;
  makeQuestion();
  renderQuestion();
  renderProgress();
  renderWrongList();
}

function sample(array) {
  return array[Math.floor(Math.random() * array.length)];
}

function shuffle(array) {
  return [...array].sort(() => Math.random() - 0.5);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

els.shuffleBtn.addEventListener("click", () => {
  makeQuestion();
  renderQuestion();
});

els.knownBtn.addEventListener("click", () => {
  if (!currentQuestion) return;
  state.done[currentQuestion.item.id] = true;
  delete state.wrong[currentQuestion.item.id];
  state.familiarity[currentQuestion.item.id] = Math.min(5, (state.familiarity[currentQuestion.item.id] || 0) + 1);
  saveState();
  render();
});

els.againBtn.addEventListener("click", () => {
  if (!currentQuestion) return;
  state.wrong[currentQuestion.item.id] = true;
  state.familiarity[currentQuestion.item.id] = Math.max(-3, (state.familiarity[currentQuestion.item.id] || 0) - 1);
  saveState();
  render();
});

els.wrongOnlyBtn.addEventListener("click", () => {
  wrongOnly = !wrongOnly;
  els.wrongOnlyBtn.classList.toggle("active", wrongOnly);
  render();
});

els.resetTodayBtn.addEventListener("click", () => {
  filteredItems().forEach((item) => {
    delete state.done[item.id];
  });
  saveState();
  render();
});

render();
